﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Ad.Tool;
using UnityEngine.SceneManagement;
public class GameEnter : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        AdManager.Instance.Init(0,false,()=> {
            SceneManager.LoadScene("Launch");
        });
    }
}
