﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
namespace Ad.Data
{
    public class AdData
    {
        public string key { get; private set; }
        public string value { get; private set; }
    }
}
