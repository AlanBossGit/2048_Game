﻿namespace  Ad.Tool
{
    public delegate void AdStateCallback(AdState state);
}
