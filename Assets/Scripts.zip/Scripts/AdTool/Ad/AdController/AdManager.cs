﻿using Ad.Google;
using GoogleMobileAds.Api;
using UnityEngine;
using UnityEngine.Events;

namespace Ad.Tool
{
    /// <summary>
    ///  广告类型
    /// </summary>
    public enum AdType
    {
        Null = -1,
        Reward,
        Banner,
        Interstitial,
        RewardedInterstitial,
        Count
    }
    /// <summary>
    /// 广告播放状态
    /// </summary>
    public enum AdState
    {
        Null = -1,
		NoNetwork,   //无网络
		AdEnter,     //刚进入广告
        AdSucceed,   //播放成功
        AdPlaying,   //广告播放中
        AdDefeated,  //播放失败
        AdExit,      //中途退出广告
        Count
    }
    /// <summary>
    /// 平台区分
    /// </summary>
    public enum PlatformType
    {
        Null = -1,
        Google,
        TouTiao,
        Count
    }


    /// <summary>
    /// 广告管理器
    /// </summary>
    public class AdManager : SingletonClass<AdManager>
    {
        #region 常量
        private const string ISCLEARADBANNER = "isClearAdBanner";
        private const string ISCLEARADREWARD = "isClearAdReward";
        private const string ISCLEARADINTERSTITIAL = "isClearAdInterstitial";
        private const string ISCLEARALLAD = "isClearAllAd";
        private const string ISCLEARADREWARDEDINTERSTITIAL = "isClearAdRewardedInterstitial";
        #endregion


        //是否为测试
        private bool isTest;
        //平台类型
        private PlatformType platformType;
        //平台广告基类
        private IAdManager iad;

        //*******广告开关*******//
        //是否清除Banner广告
        private int isClearAdBanner;
        //是否清除激励广告
        private int isClearAdReward;
        //是否清除插页广告
        private int isClearAdInterstitial;
        //是否清除激励插页广告
        private int isClearAdRewardedInterstitial;
        //是否清除所有广告
        private int isClearAllAd;

        /// <summary>
        /// 初始化
        /// </summary>
        /// <param name="index">平台索引（0:谷歌 1:头条）</param>
        /// <param name="isTest">是否用测试id</param>
        public void Init(int index, bool isTest,UnityAction onfinish)
        {
            AdIDFileName adIDFileName = AdIDFileName.Null;
#if UNITY_EDITOR
            isTest = true;
#endif

#if UNITY_IOS
            adIDFileName=AdIDFileName.iOSAdID;
#elif UNITY_ANDROID
            adIDFileName = AdIDFileName.AndroidAdID;
#endif
            DataInit(adIDFileName,index,isTest,onfinish);
        }



        private void DataInit(AdIDFileName name, int index, bool isTest,UnityAction onfinish)
        {
            LoadJsonFile.Instance.InitJson(name.ToString(), () => {
                onfinish.Invoke();
                platformType = (PlatformType)index;
                Debug.Log( "1类型：" + platformType.ToString());
                this.isTest = isTest;
                PlatformTypeCheack(platformType);
                isClearAdBanner = PlayerPrefs.GetInt(ISCLEARADBANNER, 0);
                isClearAdInterstitial = PlayerPrefs.GetInt(ISCLEARADINTERSTITIAL, 0);
                isClearAdReward = PlayerPrefs.GetInt(ISCLEARADREWARD, 0);
                isClearAllAd = PlayerPrefs.GetInt(ISCLEARALLAD, 0);
                isClearAdRewardedInterstitial = PlayerPrefs.GetInt(ISCLEARADREWARDEDINTERSTITIAL, 0);
            });
        }

        /// <summary>
        /// 平台校验
        /// </summary>
        private void PlatformTypeCheack(PlatformType type)
        {
            switch (type)
            {
                case PlatformType.Google:
                    iad = new GoogleManager(isTest);
                    break;
                case PlatformType.TouTiao:

                    break;
            }
        }

        /// <summary>
        /// 显示激励插页广告
        /// </summary>
        /// <param name="key"></param>
        /// <param name="callback"></param>
        public void ShowRewardedInterstitial(string key, AdStateCallback callback = null)
        {
            if (CheackAdCondition() || isClearAdRewardedInterstitial.Equals(1)) return;
            iad.ShowRewardedInterstitial(key,callback);
        }

        /// <summary>
        /// 显示Banner广告牌
        /// </summary>
        /// <param name="key"></param>
        /// <param name="callback"></param>
        public void ShowAdBanner(string key, AdPosition pos, AdStateCallback callback = null)
        {
            if (CheackAdCondition()||isClearAdBanner.Equals(1)) return;
            iad.ShowBanner(key,pos,callback);
        }

        /// <summary>
        /// 隐藏Banner广告
        /// </summary>
        public void HideAdBanner()
        {
            if ((null == iad||isClearAdBanner.Equals(1))|| isClearAllAd.Equals(1)) return;
            iad.HideBanner();
        }

        /// <summary>
        /// 显示激励广告
        /// </summary>
        /// <param name="key"></param>
        /// <param name="callback"></param>
        public void ShowAdReward(string key, AdStateCallback callback = null)
        {
            if (null == iad||isClearAdReward.Equals(1)||isClearAllAd.Equals(1)) return;
            iad.ShowReward(key, callback);
        }

        /// <summary>
        /// 隐藏激励广告
        /// </summary>
        public void HideAdReward()
        {
            if (null == iad || isClearAdReward.Equals(1) || isClearAllAd.Equals(1)) return;
            iad.HideReward();
        }


        /// <summary>
        /// 显示插屏广告
        /// </summary>
        public void ShowAdInterstitial(string key, AdStateCallback callback = null)
        {
            if (null == iad||isClearAdInterstitial.Equals(1)||isClearAllAd.Equals(1)) return;
            iad.ShowInterstitial(key, callback);
        }

        /// <summary>
        /// 隐藏插屏广告
        /// </summary>
        public void HideAdInterstitial()
        {
            if (null == iad || isClearAdInterstitial.Equals(1) || isClearAllAd.Equals(1)) return;
            iad.HideInterstitial();
        }

#region 销毁广告和恢复广告

        /// <summary>
        /// 恢复激励插页广告
        /// </summary>
        /// <param name="onFinish"></param>
        public void RegainAdRewardedInterstitial(UnityAction onFinish = null)
        {
            isClearAdRewardedInterstitial = 0;
            PlayerPrefs.SetInt(ISCLEARADREWARDEDINTERSTITIAL, isClearAdRewardedInterstitial);
            if (null != onFinish) onFinish.Invoke();
        }

        /// <summary>
        /// 销毁激励插页广告
        /// </summary>
        /// <param name="onFinish"></param>
        public void ClearAdRewardedInterstitial(UnityAction onFinish = null)
        {
            isClearAdRewardedInterstitial = 1;
            PlayerPrefs.SetInt(ISCLEARADREWARDEDINTERSTITIAL, isClearAdRewardedInterstitial);
            if (null != onFinish) onFinish.Invoke();
        }

        /// <summary>
        /// 恢复Banner广告(例如销毁时间到期后恢复广告)
        /// </summary>
        public void RegainAdBanner(UnityAction onFinish = null)
        {
            isClearAdBanner = 0;
            PlayerPrefs.SetInt(ISCLEARADBANNER, isClearAdBanner);
            if (null != onFinish) onFinish.Invoke();
        }

        /// <summary>
        /// 销毁Banner广告（用于充值去除广告）
        /// </summary>
        public void ClearAdBanner(UnityAction onFinish=null)
        {
            HideAdBanner();
            isClearAdBanner = 1;
            PlayerPrefs.SetInt(ISCLEARADBANNER, isClearAdBanner);
            if (null != onFinish) onFinish.Invoke();
        }

        /// <summary>
        /// 恢复激励广告(例如销毁时间到期后恢复广告)
        /// </summary>
        public void RegainAdReward(UnityAction onFinish = null)
        {
            isClearAdReward = 0;
            PlayerPrefs.SetInt(ISCLEARADREWARD, isClearAdReward);
            if (null != onFinish) onFinish.Invoke();
        }

        /// <summary>
        /// 销毁激励广告（用于充值去除广告）
        /// </summary>
        public void ClearAdReward(UnityAction onFinish = null)
        {
            HideAdReward();
            isClearAdReward = 1;
            PlayerPrefs.SetInt(ISCLEARADREWARD, isClearAdReward);
            if (null != onFinish) onFinish.Invoke();
        }

        /// <summary>
        /// 恢复插屏广告(例如销毁时间到期后恢复广告)
        /// </summary>
        /// <param name="onFinish"></param>
        public void RegainAdInterstitial(UnityAction onFinish = null)
        {
            isClearAdInterstitial = 0;
            PlayerPrefs.SetInt(ISCLEARADINTERSTITIAL, isClearAdInterstitial);
            if (null != onFinish) onFinish.Invoke();
        }
        /// <summary>
        /// 销毁插页广告（用于充值去除广告）
        /// </summary>
        public void ClearAdInterstitial(UnityAction onFinish = null)
        {
            HideAdInterstitial();
            isClearAdInterstitial = 1;
            PlayerPrefs.SetInt(ISCLEARADINTERSTITIAL, isClearAdInterstitial);
            if (null != onFinish) onFinish.Invoke();
        }
        
        /// <summary>
        /// 恢复所有的广告（销毁广告功能到期了）
        /// </summary>
        public void RegainAllAd(UnityAction onFinish = null)
        {
            isClearAdBanner = 0;
            isClearAdReward = 0;
            isClearAdInterstitial = 0;

            PlayerPrefs.SetInt(ISCLEARADBANNER, isClearAdBanner);
            PlayerPrefs.SetInt(ISCLEARADREWARD, isClearAdReward);
            PlayerPrefs.SetInt(ISCLEARADINTERSTITIAL, isClearAdInterstitial);
            if (null != onFinish) onFinish.Invoke();
        }

        /// <summary>
        /// 销毁所有广告
        /// </summary>
        public void ClearAllAd(UnityAction onFinish = null)
        {

            isClearAdBanner = 1;
            isClearAdReward = 1;
            isClearAdInterstitial = 1;
            isClearAdRewardedInterstitial = 1;
            HideAdReward();
            HideAdBanner();
            HideAdInterstitial();
            PlayerPrefs.SetInt(ISCLEARADBANNER, isClearAdBanner);
            PlayerPrefs.SetInt(ISCLEARADREWARD, isClearAdReward);
            PlayerPrefs.SetInt(ISCLEARADINTERSTITIAL, isClearAdInterstitial);
            if(null!=onFinish) onFinish.Invoke();
        }


#endregion

        /// <summary>
        /// 检测广告条件
        /// </summary>
        private bool CheackAdCondition()
        {
            if (null == iad)
            {
                Debug.Log("平台对象为空");
                return true;
            }else if (isClearAllAd.Equals(1))
            {
                Debug.Log("充值去除广告了，不再显示广告");
                return true;
            }
            return false;
        }
    }
}
