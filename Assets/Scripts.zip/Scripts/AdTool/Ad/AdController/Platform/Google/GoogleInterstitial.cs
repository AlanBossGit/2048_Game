﻿using System;
using GoogleMobileAds.Api;
using System.Collections.Generic;
using Ad.Tool;
using System.Diagnostics;

namespace Ad.Google
{
    public class GoogleInterstitial : GoogleAdBase, IGoogleAd
    {
        //谷歌内置插屏类
        private InterstitialAd interstitial;
        public GoogleInterstitial(string key, bool isTest)
        {
            this.isTest = isTest;
            this.adkey = (isTest ? "Test" : key).Trim();
            Init(AdType.Interstitial);
        }


        /// <summary>
        /// 初始化
        /// </summary>
        public void Load(AdStateCallback callback)
        {
            //网络检测：
            if (!AdTool.Instance.IsNetwork())
            {
                SetAdState(AdState.NoNetwork);
                UnityEngine.Debug.Log("GoogleInterstitial无网络连接，请稍后再试～");
                return;
            }
            //广告Key校验：
            if (!dictID.ContainsKey(adkey))
            {
                UnityEngine.Debug.Log(string.Format("Interstitial广告位:{0}为空", adkey));
                return;
            }
            this.callback = callback;
            SetAdState(AdState.AdEnter);
            UnityEngine.Debug.Log("谷歌插屏广告初始化成功:" + adkey);
            this.interstitial = new InterstitialAd(dictID[adkey].Trim());
            this.interstitial.OnAdLoaded += HandleOnAdLoaded;
            this.interstitial.OnAdFailedToLoad += HandleOnAdFailedToLoad;
            this.interstitial.OnAdOpening += HandleOnAdOpened;
            this.interstitial.OnAdClosed += HandleOnAdClosed;
            this.interstitial.OnAdLeavingApplication += HandleOnAdLeavingApplication;
            this.interstitial.OnPaidEvent += HandleOnPaidEvent;
            AdRequest request = new AdRequest.Builder().Build();
            this.interstitial.LoadAd(request);
            
        }

        /// <summary>
        /// 关闭插屏
        /// </summary>
        public void Hide()
        {
            if (null == interstitial)
            {
                UnityEngine.Debug.Log("GoogleInterstitial对象为空！");
                return;
            }
            SetAdState(AdState.AdExit);
            this.interstitial.Destroy();
            interstitial = null;
        }
        public AdState GetAdState()
        {
            return adState;
        }
        public bool IsSuccessPlay()
        {
            return isCurrentAdEnd;
        }
        #region 广告事件
        /// <summary>
        /// 广告加载完成时，系统会执行 OnAdLoaded 事件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="args"></param>
        private void HandleOnAdLoaded(object sender, EventArgs args)
        {
            UnityEngine.Debug.Log("插屏广告加载完成");
            if (this.interstitial.IsLoaded())
            {
                this.interstitial.Show();
            }
        }

        /// <summary>
        /// 广告加载失败时，系统会调用 OnAdFailedToLoad 事件。Message 参数用于描述发生了何种类型的失败。
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="args"></param>
        private void HandleOnAdFailedToLoad(object sender, AdFailedToLoadEventArgs args)
        {
            UnityEngine.Debug.Log("插屏广告加载失败" + args.Message);
            isCurrentAdEnd = true;
            SetAdState(AdState.AdDefeated); 
        }

        /// <summary>
        /// 在广告开始展示并铺满设备屏幕时，系统会调用此方法。
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="args"></param>
        private void HandleOnAdOpened(object sender, EventArgs args)
        {
            UnityEngine.Debug.Log("插屏广告铺满全屏");
            SetAdState(AdState.AdPlaying);
        }

        /// <summary>
        /// 此方法会在用户点按“关闭”图标或使用“返回”按钮关闭插页式广告时被调用。
        /// 如果您的应用暂停了音频输出或游戏循环，则非常适合使用此方法恢复这些活动。
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="args"></param>
        private void HandleOnAdClosed(object sender, EventArgs args)
        {
            SetAdState(AdState.AdSucceed);
            UnityEngine.Debug.Log("关闭插屏广告");
            isCurrentAdEnd = true;
            interstitial = null;
        }

        /// <summary>
        /// 用户点击打开其他应用（例如，Google Play 商店）时，系统会先调用 OnAdOpened，
        /// 再调用此方法，从而在后台运行当前应用。
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="args"></param>
        private void HandleOnAdLeavingApplication(object sender, EventArgs args)
        {
            
            UnityEngine.Debug.Log("插页广告播放完成，点击App后");

        }

        private void HandleOnPaidEvent(object sender, AdValueEventArgs e)
        {
            UnityEngine.Debug.Log("在广告预计可赚钱时调用");
        }

        #endregion
    }

}
