﻿using System.Diagnostics;
using Ad.Tool;
using GoogleMobileAds.Api;
namespace Ad.Google
{
    public class GoogleManager : IAdManager
    {

        //是否为测试：
        private bool isTest;
        //广告类型
        IGoogleAd banner;
        IGoogleAd reward;
        IGoogleAd interstitial;
        IGoogleAd appOpen;
        IGoogleAd rewardedInterstitial;
        public GoogleManager(bool istest)
        {
            this.isTest = istest;
            //移动设备谷歌初始化（使用中介广告的初始化方式，无需指定APPID）
            MobileAds.Initialize((initStatus) => {});
        }


        #region 插页激励广告
        public void ShowRewardedInterstitial(string key, AdStateCallback callback = null)
        {
            if (null != rewardedInterstitial && !rewardedInterstitial.IsSuccessPlay())
            {
                UnityEngine.Debug.Log("谷歌RewardedInterstitial已经打开");
                return;
            }
            rewardedInterstitial = new GoogleRewardedInterstitial(key,isTest);
            rewardedInterstitial.Load(callback);
        }
        public void HideRewardedInterstitial()
        {
           // UnityEngine.Debug.Log("谷歌RewardedInterstitial无手动关闭");
        }

        #endregion


        #region 激励广告处理

        public void ShowReward(string key, AdStateCallback callback = null)
        {
            if (null != reward && !reward.IsSuccessPlay())
            {
                UnityEngine.Debug.Log("谷歌Reward已经打开");
                return;
            }
            reward = new GoogleReward(key, isTest);
            reward.Load(callback);
        }

        public void HideReward()
        {
            if (null == reward)
            {
                UnityEngine.Debug.Log("谷歌Reward对象为空");
                return;
            }
            reward.Hide();
        }
        #endregion

        #region banner广告处理
        /// <summary>
        /// 显示Banner广告
        /// </summary>
        /// <param name="key">Banner广告位ID</param>
        /// <param name="pos">显示位置</param>
        /// <param name="callback">回调</param>
        public void ShowBanner(string key, AdPosition pos, AdStateCallback callback = null)
        {
            if (null != banner&&!banner.IsSuccessPlay())
            {
                UnityEngine.Debug.Log("谷歌Banner已经打开");
                return;
            }
            banner = new GoogleBanner(key,pos,isTest);
            banner.Load(callback);
        }

        /// <summary>
        /// 隐藏Banner广告
        /// </summary>
        public void HideBanner()
        {
            if (null == banner)
            {
                UnityEngine.Debug.Log("谷歌Banner对象为空");
                return;
            }
            banner.Hide();
            banner = null;
        }
        #endregion

        #region 插屏广告处理
        public void ShowInterstitial(string key = "", AdStateCallback callback = null)
        {
            if (null != interstitial &&!interstitial.IsSuccessPlay())
            {
                UnityEngine.Debug.Log("谷歌Interstitial广告已经打开");
                return;
            }
            interstitial = new GoogleInterstitial(key, isTest);
            interstitial.Load(callback);
        }

        public void HideInterstitial()
        {
            if (null == interstitial)
            {
                UnityEngine.Debug.Log("谷歌Interstitial对象为空");
                return;
            }
            interstitial.Hide();
            interstitial = null;
        }

        

        #endregion
    }

}

