﻿using Ad.Tool;
using UnityEngine;
using GoogleMobileAds.Api;
namespace Ad.Google
{
    /// <summary>
    /// 谷歌开屏广告
    /// </summary>
    public class GoogleAppOpen : GoogleAdBase, IGoogleAd
    {
       
     
        public AdState GetAdState()
        {
            return adState;
        }

        public void Hide()
        {
            
        }

        public void Load(AdStateCallback callback)
        {
            
        }

        public bool IsSuccessPlay()
        {
            throw new System.NotImplementedException();
        }
    }
}
