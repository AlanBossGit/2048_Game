﻿using System;
using GoogleMobileAds.Api;
using System.Collections.Generic;
using Ad.Tool;
using Ad.Data;
using System.Diagnostics;

namespace Ad.Google
{
    /// <summary>
    /// 谷歌Banner
    /// </summary>
    public class GoogleBanner : GoogleAdBase, IGoogleAd
    {
        private BannerView bannerView;
        private AdPosition pos;
        public GoogleBanner(string key, AdPosition pos, bool isTest)
        {
            this.isTest = isTest;
            this.pos = pos;
            this.adkey = (isTest ? "Test" : key).Trim();
            Init(AdType.Banner);
        }

        public void Load(AdStateCallback callback)
        {
            //网络检测：
            if (!AdTool.Instance.IsNetwork())
            {
                SetAdState(AdState.NoNetwork);
                UnityEngine.Debug.Log("GoogleBanner无网络连接，请稍后再试～");
                return;
            }
            //广告Key校验：
            if (!dictID.ContainsKey(adkey))
            {
                UnityEngine.Debug.Log(string.Format("GoogleBanner广告位:{0}为空", adkey));
                return;
            }
            UnityEngine.Debug.Log("谷歌Banner广告初始化成功:" + adkey);
            this.callback = callback;
            SetAdState(AdState.AdEnter);
            //Banner广告位的尺寸 600*150
            //AdSize adSize = new AdSize(600, 150);
            this.bannerView = new BannerView(dictID[adkey].Trim(), AdSize.Banner, pos);
            this.bannerView.OnAdLoaded += this.HandleOnAdLoaded;
            this.bannerView.OnAdFailedToLoad += this.HandleOnAdFailedToLoad;
            this.bannerView.OnAdOpening += this.HandleOnAdOpened;
            this.bannerView.OnAdClosed += this.HandleOnAdClosed;
            this.bannerView.OnAdLeavingApplication += this.HandleOnAdLeavingApplication;
            AdRequest request = new AdRequest.Builder().Build();
            this.bannerView.LoadAd(request);
        }

        private void Show()
        {
            if (null == bannerView) return;
            bannerView.Show();
        }

        public AdState GetAdState()
        {
            return adState;
        }
        public bool IsSuccessPlay()
        {
            return isCurrentAdEnd;
        }
        public void Hide()
        {
            if (null == bannerView)
            {
                UnityEngine.Debug.Log("GoogleBanner对象为空！");
                return;
            }
            bannerView.Hide();
            bannerView.Destroy();
            bannerView = null;
            SetAdState(AdState.AdExit);
        }

        #region 事件回调
        /// <summary>
        /// 广告加载完成时，系统会执行 OnAdLoaded 事件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="args"></param>
        private void HandleOnAdLoaded(object sender, EventArgs args)
        {
            UnityEngine.Debug.Log("Banner加载完成");
            //Show();
            SetAdState(AdState.AdPlaying);
            SetAdState(AdState.AdSucceed);
        }
        /// <summary>
        /// 广告加载失败时，系统会调用 OnAdFailedToLoad 事件 Message 参数描述发生的故障类型。
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="args"></param>
        private void HandleOnAdFailedToLoad(object sender, AdFailedToLoadEventArgs args)
        {
            UnityEngine.Debug.Log("Banner加载失败" + args.Message);
            isCurrentAdEnd = true;
            SetAdState(AdState.AdDefeated);
        }
        /// <summary>
        /// 用户点按广告时，系统会调用此方法。如果您使用分析产品包跟踪点击，则此方法很适合记录点击。
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="args"></param>
        private void HandleOnAdOpened(object sender, EventArgs args)
        {
            UnityEngine.Debug.Log("Banner广告被点击打开");
       
        }
        /// <summary>
        /// 用户查看了广告的目标网址并返回应用时，系统会调用此方法。应用可以使用此方法恢复暂停的活动，或执行任何其他必要的操作，以做好互动准备。
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="args"></param>
        private void HandleOnAdClosed(object sender, EventArgs args)
        {
            SetAdState(AdState.AdExit);
            UnityEngine.Debug.Log("Banner被关闭");
            isCurrentAdEnd = true;
            bannerView = null;
        }
        /// <summary>
        /// 用户点击打开其他应用（例如，Google Play 商店）时，系统会先调用 onAdOpened，再调用此方法，从而在后台运行当前应用。
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="args"></param>
        private void HandleOnAdLeavingApplication(object sender, EventArgs args)
        {
            UnityEngine.Debug.Log("Banner被点击，打开商城");
        }
        #endregion
    }
}
