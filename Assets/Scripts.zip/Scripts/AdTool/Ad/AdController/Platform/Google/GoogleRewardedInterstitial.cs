﻿using System;
using System.Collections;
using System.Collections.Generic;
using Ad.Google;
using Ad.Tool;
using GoogleMobileAds.Api;
using UnityEngine;
namespace Ad.Google
{
    /// <summary>
    /// 谷歌激励插页广告
    /// </summary>
    public class GoogleRewardedInterstitial : GoogleAdBase, IGoogleAd
    {
        private RewardedInterstitialAd rewardedInterstitial;

        public GoogleRewardedInterstitial(string key, bool isTest)
        {
            this.isTest = isTest;
            this.adkey = (isTest ? "Test" : key).Trim();
            Init(AdType.RewardedInterstitial);
        }

        public AdState GetAdState()
        {
            return adState;
        }
        public bool IsSuccessPlay()
        {
            return isCurrentAdEnd;
        }
        public void Hide()
        {
            if (null == rewardedInterstitial)
            {
                Debug.Log("RewardedInterstitialAd对象为空！");
                return;
            }
            SetAdState(AdState.AdExit);
            rewardedInterstitial = null;
        }

        public void Load(AdStateCallback callback)
        {

            //网络检测：
            if (!AdTool.Instance.IsNetwork())
            {
                SetAdState(AdState.NoNetwork);
                UnityEngine.Debug.Log("GoogleRewardedInterstitial无网络连接，请稍后再试～");
                return;
            }
            //广告Key校验：
            if (!dictID.ContainsKey(adkey))
            {
                UnityEngine.Debug.Log(string.Format("RewardedInterstitial广告位:{0}为空", adkey));
                return;
            }

            UnityEngine.Debug.Log("谷歌插页激励广告初始化成功：" + adkey);
            this.callback = callback;
            AdRequest request = new AdRequest.Builder().Build();
            RewardedInterstitialAd.LoadAd(dictID[adkey].Trim(), request, adLoadCallback);
        }

        private void adLoadCallback(RewardedInterstitialAd ad, string error)
        {
            if (error == null)
            {
                Debug.Log("激励插页广告事件注册");
                rewardedInterstitial = ad;
                rewardedInterstitial.OnAdFailedToPresentFullScreenContent += HandleAdFailedToPresent;
                rewardedInterstitial.OnAdDidPresentFullScreenContent += HandleAdDidPresent;
                rewardedInterstitial.OnAdDidDismissFullScreenContent += HandleAdDidDismiss;
                rewardedInterstitial.OnPaidEvent += HandlePaidEvent;
            }
            else
            {
                Debug.Log("激励插页广告错误：" + error);
                rewardedInterstitial = null;
                return;
            }
            ShowRewardedInterstitialAd();
        }


        public void ShowRewardedInterstitialAd()
        {
            if (rewardedInterstitial != null)
            {
                rewardedInterstitial.Show(userEarnedRewardCallback);
            }
        }

        private void userEarnedRewardCallback(Reward reward)
        {
            isCurrentAdEnd = true;
            Debug.Log("激励数量：" + reward.Amount);
        }

        private void HandleAdFailedToPresent(object sender, AdErrorEventArgs args)
        {
            Debug.Log("插屏激励广告显示失败");
            SetAdState(AdState.AdDefeated);
            isCurrentAdEnd = false;
            rewardedInterstitial = null;
        }

        private void HandleAdDidPresent(object sender, EventArgs args)
        {
            Debug.Log("插屏激励广告显示完成");
            isCurrentAdEnd = true;
        }

        private void HandleAdDidDismiss(object sender, EventArgs args)
        {
            if (isCurrentAdEnd)
            {
                SetAdState(AdState.AdSucceed);
                UnityEngine.Debug.Log("播放完成,关闭插屏激励广告");
            }
            else
            {
                SetAdState(AdState.AdExit);
                UnityEngine.Debug.Log("播放未完成,关闭插屏激励广告");
            }
            rewardedInterstitial = null;
        }

        private void HandlePaidEvent(object sender, AdValueEventArgs args)
        {

            Debug.Log("插屏激励广告，有奖插播广告已收到付费活动");
        }
    }
}
