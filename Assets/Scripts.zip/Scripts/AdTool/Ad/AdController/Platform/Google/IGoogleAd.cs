﻿using Ad.Tool;
namespace Ad.Google
{
    public interface IGoogleAd
    {
        //加载广告
        void Load(AdStateCallback callback);
        //隐藏广告
        void Hide();
        /// <summary>
        /// 获取当前广告状态
        /// </summary>
        AdState GetAdState();
        /// <summary>
        /// 是否成功播放广告
        /// </summary>
        /// <returns></returns>
        bool IsSuccessPlay();
    }

}
