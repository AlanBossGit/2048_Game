﻿
using System.Collections.Generic;
using System.Diagnostics;
using Ad.Data;
using Ad.Tool;

namespace Ad.Google
{
    public abstract class GoogleAdBase
    {
        /// <summary>
        /// 是否播放完成
        /// </summary>
        protected bool isCurrentAdEnd;

        /// <summary>
        /// 是否位测试
        /// </summary>
        protected bool isTest;
        /// <summary>
        /// 广告健位
        /// </summary>
        protected string adkey;
        /// <summary>
        /// 广告状态
        /// </summary>
        protected AdState adState;
        /// <summary>
        /// 广告回调
        /// </summary>
        protected AdStateCallback callback;
        /// <summary>
        /// 存取广告键位和ID的字典
        /// </summary>
        protected Dictionary<string, string> dictID;

        /// <summary>
        /// 广告类型
        /// </summary>
        protected AdType adtype;

        /// <summary>
        /// 初始化
        /// </summary>
        protected virtual void Init(AdType type) 
        {
            //广告数据加载：
            this.adtype = type;
            dictID = new Dictionary<string, string>();
            string[][] arrAdData = LoadJsonFile.Instance.GetObjectsByKeys<string>(type.ToString());
            for (int i = 0; i < arrAdData.Length; i++)
            {
                string[] arrContent = arrAdData[i];
                for (int j = 0; j < arrContent.Length; j++)
                {
                    if (!dictID.ContainsKey(arrContent[0]))
                    {
                        dictID.Add(arrContent[0],arrContent[1]);
                    }
                }
            }
        }



        /// <summary>
        /// 设置广告状态
        /// </summary>
        /// <param name="state"></param>
        protected virtual void SetAdState(AdState state)
        {
            this.adState = state;
            if (null != callback) callback.Invoke(adState);
            UnityEngine.Debug.Log("广告当前状态:"+state.ToString());
        }
    }
}
