﻿using Ad.Tool;
using GoogleMobileAds.Api;
using System;
using System.Collections.Generic;
namespace Ad.Google
{
    #region Author & Version
    /* ========================================================================  
    // 公司名称 : 极娱互动
    // 开发人员 ：Alan
    // 版本号   ：v1.0.0
    // 功能描述 ：...............................    
    // 具体更改 ：主.次.月日.时分  修改者姓名   修改内容    
    //           ............      ....      .......           
    // ========================================================================
    */
    #endregion
    public class GoogleReward : GoogleAdBase, IGoogleAd
    {
        //谷歌激励内置类：
        private RewardedAd rewardedAd;

        public GoogleReward(string key, bool isTest)
        {
            this.isTest = isTest;
            this.adkey = (isTest ? "Test" : key).Trim();
            Init(AdType.Reward);
        }


        public void Hide()
        {
            if (null == rewardedAd)
            {
                UnityEngine.Debug.Log("GoogleReward对象为空！");
                return;
            }
            SetAdState(AdState.AdExit);
            rewardedAd = null;
        }

        public AdState GetAdState()
        {
            return adState;
        }

        public bool IsSuccessPlay()
        {
            return isCurrentAdEnd;
        }

        public void Load(AdStateCallback callback)
        {
            //网络检测：
            if (!AdTool.Instance.IsNetwork())
            {
                SetAdState(AdState.NoNetwork);
                UnityEngine.Debug.Log("GoogleReward无网络连接，请稍后再试～");
                return;
            }
            if (!dictID.ContainsKey(adkey))
            {
                UnityEngine.Debug.Log(string.Format("谷歌不存在位置：｛0｝的激励广告", adkey));
                return;
            }
            UnityEngine.Debug.Log("谷歌激励广告初始化成功：" + adkey);
            this.callback = callback;
            SetAdState(AdState.AdEnter);
            rewardedAd = new RewardedAd(dictID[adkey].Trim());
            this.rewardedAd.OnAdLoaded += HandleRewardedAdLoaded;
            this.rewardedAd.OnAdFailedToLoad += HandleRewardedAdFailedToLoad;
            this.rewardedAd.OnAdOpening += HandleRewardedAdOpening;
            this.rewardedAd.OnAdFailedToShow += HandleRewardedAdFailedToShow;
            this.rewardedAd.OnUserEarnedReward += HandleUserEarnedReward;
            this.rewardedAd.OnAdClosed += HandleRewardedAdClosed;
            AdRequest request = new AdRequest.Builder().Build();
            this.rewardedAd.LoadAd(request);
            
        }

        /// <summary>
        /// 在广告加载完成时被调用
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="args"></param>
        private void HandleRewardedAdLoaded(object sender, EventArgs args)
        {

            if (this.rewardedAd.IsLoaded())
            {
                UnityEngine.Debug.Log("谷歌激励广告加载成功");
                this.rewardedAd.Show();
            }
        }

        /// <summary>
        /// 在广告加载失败时被调用。提供的 AdErrorEventArgs 的 Message 属性用于描述发生了何种类型的失败
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="args"></param>
        private void HandleRewardedAdFailedToLoad(object sender, AdErrorEventArgs args)
        {
            SetAdState(AdState.AdDefeated);
            isCurrentAdEnd = false;
            UnityEngine.Debug.Log("谷歌激励广告加载失败" + args.Message);
        }
        /// <summary>
        /// 在广告开始展示并铺满设备屏幕时被调用。如需暂停应用音频输出或游戏循环，则非常适合使用此方法。
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="args"></param>
        private void HandleRewardedAdOpening(object sender, EventArgs args)
        {
            SetAdState(AdState.AdPlaying);
            UnityEngine.Debug.Log("谷歌激励广告铺满全屏");
        }

        /// <summary>
        /// 在广告显示失败时被调用
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="args">用于描述发生了何种类型的失败</param>
        private void HandleRewardedAdFailedToShow(object sender, AdErrorEventArgs args)
        {
            SetAdState(AdState.AdDefeated);
            isCurrentAdEnd = true;
            UnityEngine.Debug.Log("谷歌激励广告显示失败" + args.Message);
            rewardedAd = null;
        }
        /// <summary>
        /// 在用户点按“关闭”图标或使用“返回”按钮关闭激励视频广告时被调用。如果您的应用暂停了音频输出或游戏循环，则非常适合使用此方法恢复这些活动。
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="args"></param>
        private void HandleRewardedAdClosed(object sender, EventArgs args)
        {
            if (isCurrentAdEnd)
            {
                UnityEngine.Debug.Log("显示完成，谷歌激励广告被关闭");
                SetAdState(AdState.AdSucceed);
            }
            else
            {
                UnityEngine.Debug.Log("显示未完成，谷歌激励广告被关闭");
                SetAdState(AdState.AdExit);
            }
            isCurrentAdEnd = true;
            rewardedAd = null;
        }
        /// <summary>
        /// 在用户因观看视频而应获得奖励时被调用
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="args">描述了要呈现给用户的奖励</param>
        private void HandleUserEarnedReward(object sender, Reward args)
        {
            isCurrentAdEnd = true;
            UnityEngine.Debug.Log("谷歌激励广告观看完毕，可领取奖励");
        }


    }

}
