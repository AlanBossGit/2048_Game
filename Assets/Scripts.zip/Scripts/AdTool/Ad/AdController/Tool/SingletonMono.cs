﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
namespace Ad.Tool
{
    /// <summary>
    /// 单例组件
    /// </summary>
    public class SingletonMono<T> : MonoBehaviour where T : MonoBehaviour
    {
        private static T _instance;
        private static object m_Lock = new object();
        public static T Instance
        {
            get
            {
                lock (m_Lock)
                {
                    if (_instance == null)
                    {
                        string _name = typeof(T).Name;
                        GameObject go = GameObject.Find(_name);
                        if (go == null)
                        {
                            go = new GameObject(_name);
                            _instance = go.AddComponent<T>();
                        }
                        else
                        {
                            _instance = go.GetComponent<T>();
                        }
                    }
                    return _instance;
                }
            }
        }

        protected virtual void Awake()
        {
            _instance = this as T;
        }
    }
}