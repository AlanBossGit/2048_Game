﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
namespace Ad.Tool
{
    public class AdTool : SingletonClass<AdTool>
    {
        /// <summary>        /// 判断当前是否有网络        /// </summary>        /// <returns></returns>        public bool IsNetwork()
        {
            switch (Application.internetReachability)
            {
                case NetworkReachability.ReachableViaLocalAreaNetwork:
                    //wifi
                    return true;
                case NetworkReachability.ReachableViaCarrierDataNetwork:
                    //移动网络
                    return true;
                case NetworkReachability.NotReachable:
                default:
                    //断网
                    return false;
            }
        }

    }
}
