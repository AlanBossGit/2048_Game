﻿
using GoogleMobileAds.Api;

namespace Ad.Tool
{
    public interface IAdManager
    {

        //显示banner
        void ShowBanner(string key, AdPosition pos, AdStateCallback callback);

        //隐藏Banner
        void HideBanner();

        //显示激励广告
        void ShowReward(string key, AdStateCallback callback);

        //隐藏激励广告
        void HideReward();
        //显示插屏广告
        void ShowInterstitial(string key, AdStateCallback callback);
        //隐藏插屏广告
        void HideInterstitial();
        //显示激励插页广告
        void ShowRewardedInterstitial(string key, AdStateCallback callback);
        //隐藏激励插页广告
        void HideRewardedInterstitial();
    }
}
