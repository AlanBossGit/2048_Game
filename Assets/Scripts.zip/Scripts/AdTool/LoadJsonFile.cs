using Ad.Tool;
using LitJson;
using System.Collections;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.Networking;

namespace Ad.Tool
{
    /// <summary>
    /// 广告文件名字
    /// </summary>
    public enum AdIDFileName
    {
        Null,
        AndroidAdID,
        iOSAdID,
        Count
    }

    public class LoadJsonFile : SingletonMono<LoadJsonFile>
    {
        //Json文件字符串
        private JsonData jsonData;
        private JsonData JsonData_text;


        protected override void Awake()
        {
            base.Awake();
            DontDestroyOnLoad(this.gameObject);
        }
        #region 外部引用
        /// <summary>
        /// 初始化
        /// </summary>
        /// <param name="fileName"></param>
        public void InitJson(string fileName, UnityAction action)
        {
        //设置路径
        string path = "";
#if UNITY_EDITOR || UNITY_IOS
        //设置路径
        path = "file://" + Application.streamingAssetsPath  + "/AdIDText/" + fileName + ".json";
#elif UNITY_ANDROID
        //设置路径
        path = Application.streamingAssetsPath + "/AdIDText/" + fileName + ".json";
#endif
            StartCoroutine(GetJsonStr(path, action));
        }

        /// <summary>
        /// 根据键获取单个字符串
        /// </summary>
        /// <param name="key"></param>
        /// <returns></returns>
        public string GetStrByKey(string key)
        {
            return JsonData_text[key].ToString();
        }

        /// <summary>
        /// 根据键获取对象数组
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="key"></param>
        /// <returns></returns>
        public T[] GetObjectsByKey<T>(string key)
        {
            JsonData objs = jsonData[key];
            string objStr = JsonMapper.ToJson(objs);
            return JsonMapper.ToObject<T[]>(objStr);
        }

        public T GetObjectByKey<T>(string key)
        {
            JsonData objs = jsonData[key];
            string objStr = JsonMapper.ToJson(objs);
            return JsonMapper.ToObject<T>(objStr);
        }

        public T[][] GetObjectsByKeys<T>(string key)
        {
            JsonData objs = jsonData[key];
            string objStr = JsonMapper.ToJson(objs);
            return JsonMapper.ToObject<T[][]>(objStr);
        }
        //public string[] GetArray(string key){            
        //    JsonData temp = JsonData_text[key];
        //    string[] tempStr = new string[temp.Count];
        //    int i = 0;
        //    foreach(JsonData item in temp)
        //    {
        //        tempStr[i] = item[i].ToString();
        //    }
        //    return tempStr;
        //}
        #endregion

        /// <summary>
        /// 加载Json字符串
        /// </summary>
        private IEnumerator GetJsonStr(string path, UnityAction action)
        {
            UnityWebRequest webRequest = UnityWebRequest.Get(path);
            yield return webRequest.SendWebRequest();
            if (webRequest.isHttpError || webRequest.isNetworkError)
                Debug.Log(webRequest.error);
            else
            {
                string jsonStr = webRequest.downloadHandler.text;
                jsonData = JsonMapper.ToObject(jsonStr);
                Debug.Log("json内容："+jsonStr);
                action();
            }
        }
    }
}
